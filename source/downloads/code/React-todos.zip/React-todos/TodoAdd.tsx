import React from 'react'
import { isPropertySignature } from 'typescript'

//属性的类型
type Props={
  onAddToDo(text:string):void
}
//状态的类型
type State={
  text:string
}
class TodoAdd extends React.Component<Props,State> {
  state:State={
    text:''
  }
  onChange= (e:React.ChangeEvent<HTMLInputElement>)=>{
    this.setState({
      text:e.target.value
    })
  }
  onAdd=(e:React.KeyboardEvent<HTMLInputElement>)=>{
    //1.非空判断
    const{text}=this.state
    //去空格
    if (text.trim()==='') {
      return
    }
   

    // console.log(e.keyCode)
    // console.log(e.code);
    if(e.code==='Enter'){
      this.props.onAddToDo(this.state.text)
       //2.清空文本框的值
       this.setState({
        text:''
       })
    }
     
  }
  render() {
    return (
      <header className="header">
        <h1>todos</h1>
        <input
          className="new-todo"
          placeholder="What needs to be done?"
          autoFocus
          value={this.state.text}
          onChange={this.onChange}
          onKeyDown={this.onAdd}
        />
      </header>
    )
  }
}

export default TodoAdd