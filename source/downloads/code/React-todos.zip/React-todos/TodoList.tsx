import React from "react";
import { TodoItem } from "../todos";

// type TodoItem={
//     id: number
//     text :string
//     done: boolean

// }

interface Props{
    list: TodoItem[]
}

class TodoList extends React.Component<Props> {
    render() {
        console.log(this.props)
      return (
        <ul className="todo-list">
          {/* 编辑样式：editing  已完成样式：completed */}
          {
            //map 遍历
            this.props.list.map(todo =>{
                return(
                <li key={todo.id} className={todo.done ? 'completed' : ''}>
                    <div className="view">
                    <input className="toggle" type="checkbox" />
                    <label>{todo.text}</label>
                    <button className="destroy" />
                    </div>
                    <input className="edit" defaultValue="Create a TodoMVC template" />
                </li>
                )
            })
          }
        </ul>
      )
    }
  }


export default TodoList