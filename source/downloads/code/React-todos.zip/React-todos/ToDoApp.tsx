/*
展示任务列表

1. 为父组件APP1 ，提供状态（任务列表书记）和类型
2. 为子组件 TodoList 指定能够接收到的Props类型
3. 将任务列表数据传递给TodoList
*/

import { Component } from "react"
import TodoAdd from "./components/TodoAdd"
import TodoFooter from "./components/TodoFooter"
import TodoList from "./components/TodoList"
import './ToDoApp.css'
import{TodoItem} from './todos'
//任务项的类型
// type TodoItem={
//     id: number
//     text :string
//     done: boolean

// }
//APP组件的状态类型
type Todos={
    todos: TodoItem[]
}
const todos:TodoItem[] = [
    {
        id:1,
        text:'吃饭',
        done:true
    },
    {
        id:2,
        text:'休息',
        done:false
    },
]

class ToDoApp extends Component<{},Todos>{

    state: Todos={
        todos
    }
    addTodo=(text:string)=>{
        // console.log(text);
        const{todos}=this.state
        const id =todos.length===0?1:todos[todos.length-1].id+1
        this.setState({
            todos:[...this.state.todos,
                {
                    id,
                    text,
                    done:false
                }
            ]
        })
        
    }
    render(){
        return (
            <section className="todoapp">
              {/* 添加任务 */}
              <TodoAdd onAddToDo={this.addTodo}/>
      
              <section className="main">
                <input id="toggle-all" className="toggle-all" type="checkbox" />
                <label htmlFor="toggle-all">Mark all as complete</label>
                {/* 列表组件 */}
                <TodoList list={this.state.todos}/>
              </section>
      
              {/* footer 组件 */}
              <TodoFooter />
            </section>
          )
    }
}

export default ToDoApp;